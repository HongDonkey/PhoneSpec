package org.springframework.boot;

public class SpringApplication {

}
